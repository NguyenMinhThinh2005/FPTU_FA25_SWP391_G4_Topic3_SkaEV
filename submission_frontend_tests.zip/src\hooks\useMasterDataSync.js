﻿import React from "react";
import useBookingStore from "../store/bookingStore";
import useAuthStore from "../store/authStore";

/**
 * Master Data Sync - Đảm bảo tất cả components sử dụng cùng data
 * Sử dụng function này trong tất cả các components cần data
 */
export const useMasterDataSync = () => {
  // user not currently used here; keep auth store access for future uses
  useAuthStore();
  const { bookingHistory, getBookingStats } = useBookingStore();

  // Return unified stats
  const stats = getBookingStats();

  // Add debugging info
  React.useEffect(() => {
    if (bookingHistory.length > 0) {
      console.log("📊 Master Data Sync - Current stats:", {
        total: stats.total,
        completed: stats.completed,
        totalAmount: stats.totalAmount,
        totalEnergyCharged: stats.totalEnergyCharged,
        bookingHistoryLength: bookingHistory.length,
      });
    }
  }, [stats, bookingHistory.length]);

  return {
    bookingHistory,
    stats,
    completedBookings: bookingHistory.filter((b) => b.status === "completed"),
    isDataReady: bookingHistory.length > 0,
  };
};
