﻿import React from 'react';
import IncidentManagementComponent from '../../components/admin/IncidentManagement';

const IncidentManagementPage = () => {
  return <IncidentManagementComponent />;
};

export default IncidentManagementPage;
